# Project 03 — Privileged Access Risk Reduction Program

> ⚠️ Constructed case study. Northstar Global is fictional.
> **Status: scaffolded.** Structure, risk narrative, baseline and target metrics are complete. Artefacts
> marked *To build* are not yet written.

**Role played:** Project Manager / Privileged Access Lead
**Origin:** Risks R-02 and R-10 from [Project 01](../01-risk-assessment/)
**Technical evidence:** Lab 1 — Tenant Configuration & Role Management · Lab 9 — PIM, Access Reviews & Entitlements · Lab 10 — Monitoring, Logs & Identity Secure Score

---

## The risk-to-project chain

| Step | Statement |
| --- | --- |
| **Risk identified** | R-02: permanent standing privileged assignments (inherent 15, High). R-10: break-glass accounts undocumented, unmonitored, untested (10, Moderate). |
| **Impact assessed** | 68 standing privileged assignments across four high-impact roles. Any single credential compromise yields permanent, unmonitored, unapproved administrative control of the tenant. |
| **Appetite breach** | Yes — the appetite statement records *no appetite for standing privileged access to financial systems*. |
| **Treatment selected** | Least privilege + PIM eligible assignments + JIT elevation + approval + MFA on activation + monitoring. |
| **Delivered as** | This project — 8 weeks, Wave 1 of the treatment plan. |
| **Residual measured** | R-02: 15 → 5. R-10: 10 → 5. |
| **Reported** | KRI-02 and KRI-10 monthly; executive dashboard quarterly. |

## Current privileged role inventory

| Role | Standing assignments | Impact if compromised | Classification |
| --- | :-: | --- | --- |
| Global Administrator | 12 | Full tenant control | Tier 0 |
| Privileged Role Administrator | 22 | Can grant itself any role — functionally Tier 0 | Tier 0 |
| Exchange Administrator | 18 | Mailbox access, transport rules, BEC enablement | Tier 1 |
| Application Administrator | 16 | Can add credentials to any service principal — privilege escalation path | Tier 0 |
| **Total** | **68** | | |

The classification is the analytical work here. Application Administrator is commonly treated as Tier 1
because the name sounds application-scoped, but the ability to add credentials to an existing service
principal means it can inherit any permission that principal holds — including directory-wide write. It is
classified Tier 0 on that basis. Getting this wrong is how organisations implement PIM correctly and
remain compromised.

## Tiering model

| Tier | Definition | Controls required |
| --- | --- | --- |
| Tier 0 | Control of identity infrastructure or a path to it | Eligible only · approval required · MFA on activation with phishing-resistant method · max 4h · justification mandatory · alert on every activation |
| Tier 1 | Control of business-critical services | Eligible only · MFA on activation · max 8h · justification mandatory |
| Tier 2 | Delegated administrative scope | Eligible · MFA on activation · max 8h · no approval |
| Tier 3 | Read-only / reporting | Permanent assignment acceptable · reviewed annually |

## Before and after

| Metric | Before | After |
| --- | :-: | :-: |
| Permanent Global Administrators | 12 | 2 (break-glass only) |
| Total standing privileged assignments | 68 | 2 |
| Eligible rather than permanent | 0% | 97% |
| MFA required on activation | 0% | 100% |
| Approval required for Tier 0 activation | 0% | 100% |
| Maximum elevation duration | Unlimited | 4h (Tier 0) / 8h (Tier 1) |
| Privileged access reviewed quarterly | No | Yes |
| Alerting on privileged activation | None | All Tier 0 activations |
| Break-glass accounts tested | Never | Semi-annually, evidenced |

## Artefact plan

| # | Artefact | Status | Note |
| --- | --- | --- | --- |
| 1 | Privileged access risk assessment | To build | Extends R-02 and R-10 with attack-path analysis |
| 2 | Role inventory & privilege classification matrix | To build | The 68 assignments, classified and justified |
| 3 | Tiering model & least-privilege standard | To build | Merged. The standard is the policy artefact auditors ask for |
| 4 | PIM design & approval workflow | To build | Activation duration, approvers, justification, notification routing |
| 5 | Break-glass account design | To build | Two accounts, FIDO2 custody, CA exclusion, alerting, tested-use procedure |
| 6 | Control matrix | To build | Control → risk → framework → owner → test method |
| 7 | Implementation plan, pilot & rollout schedule | To build | Merged. IT pilot → Tier 1 → Tier 0, with rollback criteria |
| 8 | RAID log | To build | The live one, not a sanitised end-state version |
| 9 | Security metrics & executive dashboard | To build | Before/after plus ongoing KRI-02, KRI-10 |

## The risk this project itself carries

Worth writing into the RAID log rather than leaving implicit: **converting all standing access to eligible
creates a self-lockout scenario.** If PIM, Conditional Access and the approval workflow are misconfigured
simultaneously, nobody can elevate to fix it. This is why break-glass design (artefact 5) is sequenced
*before* the PIM conversion, not after — and why the pilot runs on the IT team's own accounts first.

Interviewers notice when a candidate can name the risk their own remediation introduces.

## Interview positioning

**GRC route:** the classification matrix and tiering model — how privilege was assessed against business
impact rather than role name, and how the appetite statement forced the decision.

**IAM route:** open Lab 9 and demonstrate PIM configuration, activation settings, approval workflow and
access review setup against these requirements.
