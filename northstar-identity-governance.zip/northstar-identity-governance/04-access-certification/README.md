# Project 04 — Identity Access Certification Program

> ⚠️ Constructed case study. Northstar Global is fictional.
> **Status: scaffolded.** Structure, risk narrative, tiering and metric definitions are complete.
> Artefacts marked *To build* are not yet written.

**Role played:** Identity Governance Lead
**Origin:** Risks R-05, R-09 and R-13 from [Project 01](../01-risk-assessment/)
**Technical evidence:** Lab 9 — PIM, Access Reviews & Entitlements · Lab 3 — External Identities & Cross-Tenant Access (guest/contractor reviews)

---

## The risk-to-project chain

| Step | Statement |
| --- | --- |
| **Risk identified** | R-05: no periodic certification for critical applications (inherent 16, High). R-09: guest accounts without expiry or review (9, Moderate). R-13: undetected SoD conflicts in finance (15, High). |
| **Impact assessed** | Zero of four Tier 1 applications could produce evidence of a review. 90 guests, 61 dormant beyond 180 days, oldest created 2021. 23 SoD conflicts including vendor creation combined with payment release. |
| **Appetite breach** | R-05 and R-13 both exceed the threshold of 15. |
| **Treatment selected** | Risk-tiered access certification with named application owners, auto-revoke on non-response, exception register, and preventive SoD encoded into access packages. |
| **Delivered as** | This project — 16 weeks, Wave 3 of the treatment plan. |
| **Residual measured** | R-05: 16 → 8. R-09: 9 → 6. R-13: 15 → 10 (partially accepted, ACC-02). |
| **Reported** | Quarterly certification report to Audit & Risk Committee; KRI-05, KRI-09, KRI-13. |

## Application risk classification

| Tier | Criteria | Applications | Frequency | Reviewer |
| --- | --- | --- | --- | --- |
| **Tier 1 — Critical** | Financial transaction capability, personal data at scale, production dependency, or privileged group | SAP S/4HANA, Dynamics 365 HR, privileged Entra groups, OT historian front end | Quarterly | Application owner + line manager (dual) |
| **Tier 2 — High** | Customer data or sensitive internal information | Dynamics 365 Sales, quality system, contractor access packages | Semi-annual | Application owner |
| **Tier 3 — Standard** | Limited sensitivity, low blast radius | Remaining SaaS and internal tools | Annual | Line manager |

Guest and contractor populations are reviewed on the frequency of the **highest tier they can reach**, not
on their own classification. A contractor with SAP access is a Tier 1 review regardless of employment
status. This is the design decision that stops the contractor population becoming the gap it is in most
organisations.

## Review types and reviewer responsibility

| Review type | Reviewer | Why this reviewer |
| --- | --- | --- |
| Manager certification | Line manager | Knows whether the person still does the job |
| Application owner certification | Named app owner | Knows what the entitlement actually permits |
| Privileged group review | CISO delegate | Tier 0 access is not a line-manager decision |
| Contractor review | Sponsor + app owner | Sponsor confirms engagement is live; owner confirms need |
| Guest review | Sponsoring employee | If no sponsor can be identified, access is removed by default |
| Self-review | **Not permitted** | A control that lets people approve their own access is not a control |

Manager certification alone is the most common design and the weakest. Managers approve because declining
creates conflict and they cannot tell what "SAP_FI_VENDOR_MAINT" grants. Dual review for Tier 1 costs more
reviewer time and is the difference between a certification programme and a rubber stamp.

## Non-response handling

| Outcome | Action |
| --- | --- |
| Reviewer approves | Access retained, decision logged with justification |
| Reviewer denies | Access revoked within 5 business days, confirmed |
| **No response by deadline** | **Access revoked** (auto-revoke on non-response) |
| Exception requested | Routed to exception process; requires business justification, compensating control, expiry ≤6 months |

Auto-revoke on non-response is the single most contested configuration decision in any certification
programme, and the one that determines whether it works. The alternative — retain on non-response — means
a reviewer who ignores the email achieves exactly the outcome the review exists to prevent. Rollout
therefore begins with Tier 2 to build reviewer habit before auto-revoke is enabled on Tier 1.

## Artefact plan

| # | Artefact | Status | Note |
| --- | --- | --- | --- |
| 1 | Access certification policy | To build | The governing artefact — scope, authority, frequency, roles, enforcement |
| 2 | Application risk classification & review matrix | To build | Merged. Tier criteria, application inventory, reviewer assignment |
| 3 | Reviewer responsibilities & workflows | To build | Manager, app owner, privileged, contractor and guest workflows in one document |
| 4 | SoD conflict matrix | To build | Finance role pairs, encoded as mutually exclusive access packages |
| 5 | Exception & escalation procedure | To build | Approval authority, expiry, compensating controls, register |
| 6 | KPI/KRI dashboard specification | To build | Metric definitions, data sources, thresholds |
| 7 | Quarterly executive report template | To build | Populated with one modelled cycle so it is not an empty template |

Artefact 7 matters more than it looks. A blank template proves you know a report should exist. A populated
one with real numbers, an overdue item and a declining reviewer response rate proves you have thought
about what happens when the programme underperforms.

## Programme metrics

| Metric | Type | Target | Note |
| --- | --- | --- | --- |
| Certifications completed on time | KPI | ≥95% | Programme health |
| Reviewer response rate | KPI | ≥90% | Leading indicator of rubber-stamping if it hits 100% with 0% revocations |
| Access revoked per cycle | KPI | Trending down | High in cycle 1 is success, not failure |
| Dormant accounts identified | KPI | Trending down | |
| Overdue certifications | KRI | 0 | KRI-05 |
| Contractors with expired access | KRI | 0 | KRI-03 |
| Guests dormant >90 days | KRI | ≤5 | KRI-09 |
| Unresolved SoD conflicts | KRI | ≤23 | KRI-13, at accepted baseline |
| Open exceptions past expiry | KRI | 0 | |

**Reviewer response rate at 100% with a 0% revocation rate is a red flag, not a green one.** It means
reviewers are approving everything without reading. The first cycle at Northstar is modelled at 94%
response with 11% of entitlements revoked; a later cycle showing 99% response and 0.5% revocation would
trigger a sampling audit of reviewer decisions.

## Interview positioning

**GRC route:** the certification policy, tiering rationale, SoD matrix and executive reporting — the
IGA / Identity Governance Analyst conversation.

**IAM route:** open Lab 9 and demonstrate Access Reviews configuration, access package separation of
duties, and the auto-revoke settings that implement this design.
