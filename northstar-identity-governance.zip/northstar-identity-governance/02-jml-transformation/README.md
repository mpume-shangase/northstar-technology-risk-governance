# Project 02 — IAM Joiner–Mover–Leaver Transformation

> ⚠️ Constructed case study. Northstar Global is fictional.
> **Status: scaffolded.** Structure, risk narrative and artefact plan are complete. Artefacts marked
> *To build* are not yet written.

**Role played:** Project Manager / IAM Lead
**Origin:** Risks R-01, R-03 and R-04 from [Project 01](../01-risk-assessment/)
**Technical evidence:** Lab 2 — User & Group Lifecycle with PowerShell · Lab 4 — Hybrid Identity with
Entra Connect · Lab 9 — PIM, Access Reviews & Entitlements ·
**[IAM-Lifecycle-Automation](https://github.com/mpume-shangase/IAM-Lifecycle-Automation)** — working
PowerShell + Graph JML pipeline with certificate auth, dry-run mode and audit logging

---

## The risk-to-project chain

This project exists because the assessment found something, not because lifecycle automation is a good
idea in the abstract. That distinction is the whole point of this section.

| Step | Statement |
| --- | --- |
| **Risk identified** | R-01: terminated employees retain active accounts (inherent 20, Critical). R-03: contractors retain access beyond engagement end (16, High). R-04: entitlement accumulation after transfer (12, Moderate). |
| **Impact assessed** | Median 9 days from termination to disable. 34 terminated accounts active at assessment, one for 41 days with retained SAP access. 0% of contractor identities carry an expiry date. |
| **Appetite breach** | Two of three scenarios exceed the Committee threshold of 15. |
| **Treatment selected** | HR-driven identity lifecycle with automated joiner, mover and leaver workflows; role-based birthright access; sponsor-and-expiry model for non-employees. |
| **Delivered as** | This project — 12 weeks, Wave 2 of the treatment plan, CAD 61,000. |
| **Residual measured** | R-01: 20 → 5. R-03: 16 → 8. R-04: 12 → 6. |
| **Reported** | Monthly KPIs to steering group; KRI-01, KRI-03, KRI-04 to Audit & Risk Committee quarterly. |

## Current state

```
HR email  →  Service desk ticket  →  Manual account creation  →  Manager requests apps  →  IT assigns groups
```

Failure modes measured during assessment:

| Failure | Measured |
| --- | --- |
| Late provisioning | 31% of joiners lacked full access on day one; mean 2.4 days to productive |
| Inconsistent permissions | Two plant supervisors hired in the same month received different group sets |
| Delayed termination | Median 9 days; worst case 41 days |
| Privilege accumulation | No removal step exists in the mover path — access is additive only |
| No audit trail | Entitlement grants cannot be traced to an approver for 3 of 4 Tier 1 applications |

## Future state

```
HR system (source of authority)
   → Lifecycle Workflow (joiner / mover / leaver)
      → Role-based birthright access (dynamic groups)
         → Access package request + approval (non-birthright)
            → Provisioning
               → Periodic access review
                  → Automated offboarding + session revocation
```

## Artefact plan

Consolidated from the twenty-item list in the source plan. Merges are marked, because twenty thin
documents read as padding and five substantial ones read as competence.

| # | Artefact | Status | Note |
| --- | --- | --- | --- |
| 1 | Project charter | To build | Includes problem statement, business case, scope/out-of-scope, success criteria, high-level milestones — one document, not five |
| 2 | Stakeholder register & RACI | To build | Merged. RACI covers the six lifecycle decision points, not every task |
| 3 | Business requirements | To build | ~25 numbered requirements traceable to risks R-01/R-03/R-04 and to test cases |
| 4 | Current & future state process | To build | Mermaid swimlanes, both states in one document for comparison |
| 5 | RBAC model | To build | Birthright vs requestable; role catalogue for the six business units; naming standard |
| 6 | Project schedule & RAID log | To build | Merged. 12-week schedule with dependencies; RAID maintained against it |
| 7 | Engagement & change plan | To build | Merged communications + change management. Plant shift-worker comms are the hard part |
| 8 | Test & UAT plan | To build | Including the negative tests — the leaver test that matters is confirming the session is actually revoked |
| 9 | KPIs & benefits realisation | To build | Baseline → target → measured, with residual risk re-scored |
| 10 | Lessons learned | To build | Written as a real retrospective, including what went wrong |

## Draft KPIs

| KPI | Baseline | Target | Measures |
| --- | --- | --- | --- |
| Median termination-to-disable | 9 days | ≤4 hours | R-01 treatment effectiveness |
| Terminated accounts active >24h | 34 | 0 | KRI-01 |
| Joiners with full access on day one | 69% | ≥98% | Business benefit, not just risk |
| Mean time to productive access | 2.4 days | ≤4 hours | Business benefit |
| Contractor identities with expiry set | 0% | 100% | R-03 |
| Mover recertification completed within 10 days | n/a | ≥95% | R-04 |
| Entitlement grants with traceable approver | 25% | 100% | Audit evidence |

Two of these seven are business benefits rather than risk reductions. That is deliberate — a lifecycle
programme sold purely on risk gets funded reluctantly; one that also removes 2.4 days of onboarding delay
across 600 annual hires gets funded on its own merits.

## Interview positioning

**GRC route:** the charter, business requirements traceability and benefits realisation — how a risk
finding became a funded, governed project with measured residual risk.

**IAM route:** the RBAC model, Lifecycle Workflow configuration and access package design — open Lab 2 and
show the provisioning working.
