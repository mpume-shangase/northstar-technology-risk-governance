# Glossary

Terms are defined as used in this repository. Where a term has a Microsoft-specific and a generic meaning,
both are given, because interviewers ask about the generic one and engineers ask about the Microsoft one.

## Risk terms

| Term | Definition |
| --- | --- |
| **Inherent risk** | Risk before treatment, scored Likelihood × Impact. Existing controls reduce it only where testing showed them *effective* — see control effectiveness below. |
| **Residual risk** | Risk remaining after treatment is implemented. Never assumed; re-scored at wave close. |
| **Risk appetite** | The board-approved threshold above which risk must be treated. At Northstar: no identity risk scoring 15 or above. |
| **Risk owner** | The executive accountable for the outcome if the risk materialises. Not the person who fixes it. |
| **Control owner** | The person accountable for the control operating as designed. Usually not the risk owner. |
| **Control effectiveness** | Effective / Partially effective / Ineffective / Absent. Only *Effective* reduces likelihood; a policy in report-only mode is documentation, not a control. |
| **Risk acceptance** | A formal, time-boxed decision to carry a risk, with named authority, compensating controls, monitoring KRI and expiry. Distinct from ignoring it. |
| **KRI** | Key Risk Indicator — leading signal that a risk is materialising. Drives escalation. |
| **KPI** | Key Performance Indicator — measures whether the programme is delivering. Does not drive escalation. |
| **SoD** | Segregation of Duties — ensuring no single identity can both initiate and approve a sensitive transaction. |

## Identity terms

| Term | Definition |
| --- | --- |
| **JML** | Joiner–Mover–Leaver. The identity lifecycle. The mover event is the one most organisations get wrong. |
| **Birthright access** | Entitlements granted automatically by role, department or location, without a request. |
| **Entitlement creep / role creep** | Accumulation of access across successive roles because provisioning is additive and nothing removes. |
| **Least privilege** | The minimum access required to perform a function, for the minimum time. |
| **JIT elevation** | Just-in-time. Privilege granted on activation for a bounded period, rather than held permanently. |
| **Standing access** | Permanently assigned privilege, active whether or not it is in use. The condition PIM exists to remove. |
| **Tier 0** | Systems and roles that control identity infrastructure, or provide a path to it. Compromise equals tenant compromise. |
| **Break-glass account** | Emergency access identity, excluded from Conditional Access, used only when normal paths fail. |
| **Workload identity** | A non-human identity — service principal, managed identity, application registration, AI agent. |
| **Orphaned account** | An identity with no accountable owner, typically surviving a leaver or a decommissioned application. |
| **Access certification** | Periodic attestation by an accountable reviewer that access is still required. Also called access review or recertification. |
| **Auto-revoke on non-response** | Removing access when a reviewer fails to respond by deadline. The configuration that determines whether certification is a control or a formality. |

## Microsoft Entra terms

| Term | Definition |
| --- | --- |
| **Conditional Access** | Policy engine evaluating signals (user, device, location, risk) to grant, block or add requirements to access. |
| **Authentication Strengths** | Policy specifying which authentication methods satisfy a requirement — used to mandate phishing-resistant MFA for privileged roles. |
| **PIM** | Privileged Identity Management. Converts standing role assignments to eligible ones with activation controls. |
| **Eligible assignment** | A role a user may activate, subject to approval, MFA and time limit — as opposed to an *active* (standing) assignment. |
| **Lifecycle Workflows** | Automates joiner, mover and leaver tasks against attribute changes from the HR source of authority. |
| **Entitlement Management** | Access packages bundling resources with a request, approval, expiry and review lifecycle. Where SoD is enforced preventively. |
| **Access Reviews** | The Entra capability implementing access certification, including auto-apply of results. |
| **Identity Secure Score** | Microsoft's weighted assessment of tenant configuration. Used here as corroboration, never as the assessment itself — it does not know which of your applications releases payments. |
| **Entra ID Governance** | The add-on licence containing Lifecycle Workflows, Entitlement Management and Access Reviews. |
| **Workload Identities Premium** | Separate licence covering Conditional Access for workload identities and workload identity risk detection. Deferred at Northstar — see acceptance ACC-01. |
